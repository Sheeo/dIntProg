#!/bin/sh
convert -size 40x40 xc:none -strokewidth 4 -stroke lime -fill none -draw 'circle 19,19 2,20' ball2.png

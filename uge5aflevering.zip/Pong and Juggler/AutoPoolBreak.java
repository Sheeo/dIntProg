/**
 * A PoolBreak that has automatic mode on by default. (For ease of
 * initialisation in Greenfoot.)
 */
public class AutoPoolBreak extends PoolBreak {
	public AutoPoolBreak() {
		super();
		autoOn();
	}
}

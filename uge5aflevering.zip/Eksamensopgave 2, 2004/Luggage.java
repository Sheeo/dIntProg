public class Luggage
{

    private int weight;
    
    public void setWeight(int w) {
        weight = w;
    }

    public int getWeight()
    {
        return weight;
    }
}
